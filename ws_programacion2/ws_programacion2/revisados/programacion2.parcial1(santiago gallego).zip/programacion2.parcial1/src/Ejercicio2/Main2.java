package Ejercicio2;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import Ejercicio1.ArchivoUtil;
import Ejercicio1.Persistencia;
import Ejercicio1.Producto;

public class Main2 {
	
	static ArrayList<Producto> listaProductos = new ArrayList<Producto>();

	public static void main(String[] args) {
		
		cargarProductos();
		
		Hilo1 miHilo1 = new Hilo1();
		Hilo2 miHilo2 = new Hilo2();
		miHilo1.runHilo();
		miHilo2.runHilo();
		
		try {
			miHilo1.join();
			miHilo2.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//imprimir lista de productos
		for(Producto producto: listaProductos) {
			System.out.println("--------------------------------");
			System.out.println("Producto: ");
			System.out.println("Codigo:"+producto.getCodigo());
			System.out.println("Nombre: "+producto.getNombre());
			System.out.println("Precio: "+ producto.getPrecio());
			System.out.println("Descripcion: "+producto.getDescripcion());
			System.out.println("Estado: "+producto.getEstado());
		}
		
		System.out.println("--------------------------------");
        System.out.println("");		
		System.out.println("HILO 1: La cantidad de ceros en el arreglo es de: "+miHilo1.getCantidadCeros());
		System.out.println("HILO 2: La suma de los numeros de la matriz es: "+miHilo2.getSuma());
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	

	private static void cargarProductos() {
		try {
			listaProductos.addAll(Persistencia.cargarProductos());
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
