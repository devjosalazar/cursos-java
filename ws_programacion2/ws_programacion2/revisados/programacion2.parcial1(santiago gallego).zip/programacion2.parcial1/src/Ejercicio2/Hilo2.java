package Ejercicio2;

public class Hilo2 extends Thread{
	
	private boolean runHilo;
	private int suma;

	public Hilo2() {
		
	}
	
	public void runHilo() {
		runHilo = true;
		this.start();
	}
	
	public void stopHilo() {
		runHilo = false;
	}
	
	@Override
	public void run() {
		//llenar matriz
		int[][] matriz = {
				{1,2,3},
				{4,5,6},
				{7,8,9}
		};
		
		suma = sumarMatriz(matriz, 0, 2);
		
		this.stopHilo();
	}

	private int sumarMatriz(int[][] matriz, int i, int j) {
		if(i == 2) {
			return matriz[i][j];
		}
		if(j == -1) {
			i++;
			j = 2;
			return sumarMatriz(matriz, i, j) + matriz[i][j];
		}else {
			return sumarMatriz(matriz, i, j-1) + matriz[i][j];
		}
	}

	public int getSuma() {
		return suma;
	}

	public void setSuma(int suma) {
		this.suma = suma;
	}
	
	
}
