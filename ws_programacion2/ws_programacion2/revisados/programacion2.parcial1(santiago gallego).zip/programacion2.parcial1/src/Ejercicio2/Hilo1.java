package Ejercicio2;

public class Hilo1 extends Thread{
	
	private boolean runHilo;
	private int cantidadCeros = 0;
	private int[] arreglo = new int[7];	

	public Hilo1() {
		
	}
	
	public void runHilo() {
		runHilo = true;
		this.start();
	}
	
	public void stopHilo() {
		runHilo = false;
	}
	
	@Override
	public void run() {
		arreglo[0] = 1;
		arreglo[1] = 2;
		arreglo[2] = 0;
		arreglo[3] = 3;
		arreglo[4] = 0;
		arreglo[5] = 0;
		arreglo[6] = 1;
		
		cantidadCeros = contarCeros(arreglo, 0);
		
		this.stopHilo();

	}

	private int contarCeros(int[] arreglo, int n) {
		if(n == arreglo.length - 1) {
			if(arreglo[n] == 0) {
				return 1;
			}
		}else if(arreglo[n] == 0) {
			return contarCeros(arreglo, n+1) + 1;
		}else {
			return contarCeros(arreglo, n+1);
		}
		return 0;
	}

	public int getCantidadCeros() {
		return cantidadCeros;
	}

	public void setCantidadCeros(int cantidadCeros) {
		this.cantidadCeros = cantidadCeros;
	}
	
	
}
