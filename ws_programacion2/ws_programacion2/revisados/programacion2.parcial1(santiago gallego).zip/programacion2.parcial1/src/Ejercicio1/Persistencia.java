package Ejercicio1;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

public class Persistencia {
	
	public static final String RUTA_ARCHIVO_PRODUCTOS = "src/resources/productos.txt";
	public static final String RUTA_ARCHIVO_CLIENTES = "src/resources/clientes.txt";
	
	//guardar productos

	public static void guardarProductos(ArrayList<Producto> listaProductos) throws IOException {
		
		String contenido = "";
		
		for(Producto producto: listaProductos) {
			
			contenido+= producto.getCodigo()+"#"+producto.getNombre()+"#"+producto.getPrecio()+"#"+producto.getDescripcion()+"#"+producto.getEstado()+"\n";
		}
		ArchivoUtil.guardarArchivo(RUTA_ARCHIVO_PRODUCTOS, contenido, false);
	}

	//guardar clientes
	
    public static void guardarClientes(ArrayList<Cliente> listaClientes) throws IOException {
		
		String contenido = "";
		
		for(Cliente cliente: listaClientes) {
			
			contenido+= cliente.getCodigo()+"@"+cliente.getCedula()+"@"+cliente.getTipoIdentificacion()+"@"+cliente.getNombre()+"@"+cliente.getApellido()+"@"+cliente.getTelefono()+"\n";
		}
		ArchivoUtil.guardarArchivo(RUTA_ARCHIVO_CLIENTES, contenido, false);
	}
    
    //cargar productos ejercicio2
    
    public static ArrayList<Producto> cargarProductos() throws FileNotFoundException, IOException {

		ArrayList<Producto> productos = new ArrayList<Producto>();
		
		ArrayList<String> contenido = ArchivoUtil.leerArchivo(RUTA_ARCHIVO_PRODUCTOS);
		String linea = "";
		
		for (int i = 0;i<contenido.size(); i++) {
			Producto miProducto = new Producto();
			linea = contenido.get(i);
			
			miProducto.setCodigo(Integer.parseInt(linea.split("#")[0]));
			miProducto.setNombre(linea.split("#")[1]);
			miProducto.setPrecio(Double.parseDouble(linea.split("#")[2]));
			miProducto.setDescripcion(linea.split("#")[3]);
			miProducto.setEstado(linea.split("#")[4]);
			
			productos.add(miProducto);
		}
		
		return productos;
    
    
	

	
    }
}
