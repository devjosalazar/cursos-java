package Ejercicio1;

import java.io.IOException;
import java.util.ArrayList;

public class Main1 {
	
	static ArrayList<Producto> listaProductos = new ArrayList<Producto>();
	static ArrayList<Cliente> listaClientes = new ArrayList<Cliente>();

	
	public static void main(String[] args) {
		
		inicializarDatos();
		try {
			Persistencia.guardarProductos(listaProductos);
			Persistencia.guardarClientes(listaClientes);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	public static void inicializarDatos() {
		
		Cliente miCliente1 = new Cliente();
		miCliente1.setCodigo(001);
		miCliente1.setCedula("1004961630");
		miCliente1.setTipoIdentificacion("Cedula de Ciudadania");
		miCliente1.setNombre("Santiago");
		miCliente1.setApellido("Gallego Gil");
		miCliente1.setTelefono("3226486094");
		
		listaClientes.add(miCliente1);
		
		Cliente miCliente2 = new Cliente();
		miCliente2.setCodigo(002);
		miCliente2.setCedula("1004961678");
		miCliente2.setTipoIdentificacion("Cedula de Ciudadania");
		miCliente2.setNombre("Maria");
		miCliente2.setApellido("Gomez");
		miCliente2.setTelefono("31136678282");
		
		listaClientes.add(miCliente2);
		
		Producto miProducto1 = new Producto();
		miProducto1.setCodigo(01);
		miProducto1.setNombre("Computador");
		miProducto1.setPrecio(890000);
		miProducto1.setDescripcion("Computador 22' 8gb Ram 256gb");
		miProducto1.setEstado("Disponible");
		
		listaProductos.add(miProducto1);
		
		Producto miProducto2 = new Producto();
		miProducto2.setCodigo(02);
		miProducto2.setNombre("Celular Samsung");
		miProducto2.setPrecio(700000);
		miProducto2.setDescripcion("Samsung S9 64gb");
		miProducto2.setEstado("Agotado");
		
		listaProductos.add(miProducto2);
		
		Producto miProducto3 = new Producto();
		miProducto3.setCodigo(03);
		miProducto3.setNombre("Tablet");
		miProducto3.setPrecio(500000);
		miProducto3.setDescripcion("Tablet Huawei 32gb");
		miProducto3.setEstado("Disponible");
		
		listaProductos.add(miProducto3);
		

	}

}
