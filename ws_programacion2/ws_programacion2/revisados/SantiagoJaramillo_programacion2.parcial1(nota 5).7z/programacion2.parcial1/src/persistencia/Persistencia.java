package persistencia;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import punto1.Cliente;
import punto1.Producto;
import punto1.Tienda;

public class Persistencia {
	public static final String RUTA_ARCHIVO_CLIENTES = "src/resources/clientes.txt";
	public static final String RUTA_ARCHIVO_PRODUCTOS = "src/resources/productos.txt";
	
	public static void cargarDatosArchivos(Tienda tienda) throws FileNotFoundException, IOException {
		ArrayList<Producto> productosCargados = cargarProductos();
		ArrayList<Cliente> clientesCargados = cargarClientes();
		
		if(productosCargados.size() > 0)
			tienda.getListaProductos().addAll(productosCargados);
		
		if(clientesCargados.size() > 0)
			tienda.getListaClientes().addAll(clientesCargados);
	}
	
//	----------------------SAVES------------------------
	
	/**
	 * Guarda en un archivo de texto todos la informaci�n de las personas almacenadas en el ArrayList
	 * @param objetos
	 * @param ruta
	 * @throws IOException
	 */
	public static void guardarProductos(ArrayList<Producto> listaProductos) throws IOException {
		String contenido = "";
		
		for(Producto producto: listaProductos) {
			contenido+= producto.getCodigo()+"#"+producto.getNombre()+"#"+producto.getPrecio()+"#"+producto.getDescripcion()+"#"+producto.getEstado()+"\n";
		}
		ArchivoUtil.guardarArchivo(RUTA_ARCHIVO_PRODUCTOS, contenido, false);
	}
	
	public static void guardarClientes(ArrayList<Cliente> listaClientes) throws IOException {
		String contenido = "";
		
		for(Cliente cliente: listaClientes) {
			contenido+= cliente.getCodigo()+"@"+cliente.getCedula()+"@"+cliente.getTipoId()+"@"+cliente.getNombre()+"@"+cliente.getApellidos()+"@"+cliente.getTelefono()+"\n";
		}
		ArchivoUtil.guardarArchivo(RUTA_ARCHIVO_CLIENTES, contenido, false);
	}
	
	
//	----------------------LOADS------------------------
	/**
	 * 
	 * @param tipoPersona
	 * @param ruta
	 * @return un Arraylist de personas con los datos obtenidos del archivo de texto indicado
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public static ArrayList<Producto> cargarProductos() throws FileNotFoundException, IOException {
		ArrayList<Producto> productos = new ArrayList<Producto>();
		ArrayList<String> contenido = ArchivoUtil.leerArchivo(RUTA_ARCHIVO_PRODUCTOS);
		String linea="";
		
		for (int i = 0; i < contenido.size(); i++) {
			linea = contenido.get(i);
			
			Producto producto = new Producto();
			producto.setCodigo(linea.split("#")[0]);
			producto.setNombre(linea.split("#")[1]);
			producto.setPrecio(Double.parseDouble(linea.split("#")[2]));
			producto.setDescripcion(linea.split("#")[3]);
			producto.setEstado(linea.split("#")[4]);
			
			productos.add(producto);
		}
		return productos;
	}
	
	public static ArrayList<Cliente> cargarClientes() throws FileNotFoundException, IOException {
		ArrayList<Cliente> clientes = new ArrayList<Cliente>();
		ArrayList<String> contenido = ArchivoUtil.leerArchivo(RUTA_ARCHIVO_CLIENTES);
		String linea="";
		
		for (int i = 0; i < contenido.size(); i++) {
			linea = contenido.get(i);
			
			Cliente cliente = new Cliente();
			cliente.setCodigo(linea.split("@")[0]);
			cliente.setCedula(linea.split("@")[1]);
			cliente.setTipoId(linea.split("@")[2]);
			cliente.setNombre(linea.split("@")[3]);
			cliente.setApellidos(linea.split("@")[4]);
			cliente.setTelefono(linea.split("@")[5]);
			
			clientes.add(cliente);
		}
		return clientes;
	}
}
