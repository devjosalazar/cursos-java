package punto1;

import java.io.IOException;
import java.util.ArrayList;

import persistencia.Persistencia;

public class Tienda {
	ArrayList<Producto> listaProductos = new ArrayList<>();
	ArrayList<Cliente> listaClientes = new ArrayList<>();
	
	public Tienda() {
		inicializarDatos();
		
		try {
			Persistencia.guardarClientes(getListaClientes());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			Persistencia.guardarProductos(getListaProductos());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void inicializarDatos() {
		Cliente cliente = new Cliente("1234", "1234", "Cedula", "Santiago", "Jaramillo Lopez", "123456789");
		getListaClientes().add(cliente);
		
		Cliente cliente2 = new Cliente("9876", "9876", "Tarjeta identidad", "Felipe", "Jaramillo Lopez", "987654321");
		getListaClientes().add(cliente2);
		
		Producto producto1 = new Producto("1234", "Laptop", 2300000, "Laptop 15 Pulgadas", "Disponible");
		getListaProductos().add(producto1);
		
		Producto producto2 = new Producto("5678", "iPhone", 5000000, "iPhone 15", "Agotado");
		getListaProductos().add(producto2);
		
		Producto producto3 = new Producto("9112", "Mochila", 50000, "Mochila excursion", "Disponible");
		getListaProductos().add(producto3);
	}

	public ArrayList<Producto> getListaProductos() {
		return listaProductos;
	}

	public void setListaProductos(ArrayList<Producto> listaProductos) {
		this.listaProductos = listaProductos;
	}

	public ArrayList<Cliente> getListaClientes() {
		return listaClientes;
	}

	public void setListaClientes(ArrayList<Cliente> listaClientes) {
		this.listaClientes = listaClientes;
	}
	
	
}
