package punto2;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import persistencia.Persistencia;
import punto1.Producto;

public class Main {
	public static void main(String[] args) {
		ArrayList<Producto> listaProductos = new ArrayList<Producto>();
		int[] arrayPrueba = {1, 2, 0, 3, 0, 0, 1};
		int[][] matrizPrueba = {
				{1, 2, 3},
				{4, 5, 6},
				{7, 8, 9}
		};
		
		try {
			listaProductos = Persistencia.cargarProductos();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		Hilo1 hilo1 = new Hilo1(arrayPrueba);
		Hilo2 hilo2 = new Hilo2(matrizPrueba);
		
		hilo1.start();
		hilo2.start();
		
		try {
			hilo1.join();
			hilo2.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		System.out.println(mostrarInfoProductos(listaProductos));
		System.out.println("El array tiene "+hilo1.getResultado()+ " ceros");
		System.out.println("La suma de los numeros de la matriz es: "+hilo2.getResultado());
	}
	
	public static String mostrarInfoProductos(ArrayList<Producto> listaProductos) {
		String info = "";
		for (Producto producto: listaProductos) {
			info += "Codigo: "+producto.getCodigo()+" - Nombre: "+producto.getNombre()+" - Precio: "+producto.getPrecio()+" - Descripcion: "+producto.getDescripcion()+" - Estado: "+producto.getEstado()+"\n";
		}
		return info;
	}
}