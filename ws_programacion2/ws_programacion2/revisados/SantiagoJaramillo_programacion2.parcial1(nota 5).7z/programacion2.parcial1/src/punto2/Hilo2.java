package punto2;

public class Hilo2 extends Thread {
	private int[][] matriz;
	private int resultado;
	
	public Hilo2(int[][] matriz) {
		this.matriz = matriz;
	}
	
	@Override
	public void run() {
		resultado = sumarDigitosMatrizRecursivamente(matriz, 0, matriz[0].length-1);
	}
	
	public int sumarDigitosMatrizRecursivamente(int[][] matriz, int i, int j) {
		if (i != matriz.length  || j < 0) {
			if (j < 0) {
				i++;
				j = matriz[0].length-1;
				return sumarDigitosMatrizRecursivamente(matriz, i, j);
			}
			else {
				
				return sumarDigitosMatrizRecursivamente(matriz, i, j-1) + matriz[i][j];
				
			}
			
		}
		return 0;
	}

	public int[][] getMatriz() {
		return matriz;
	}

	public void setMatriz(int[][] matriz) {
		this.matriz = matriz;
	}

	public int getResultado() {
		return resultado;
	}

	public void setResultado(int resultado) {
		this.resultado = resultado;
	}
}