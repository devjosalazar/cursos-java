package punto2;

public class Hilo1 extends Thread {
	private int[] array;
	private int resultado;
	
	public Hilo1(int[] array) {
		this.array = array;
	}
	
	@Override
	public void run() {
		resultado = cuentaCerosArrayRecursivamente(array, 0);
	}
	
	private int cuentaCerosArrayRecursivamente(int[] array, int index) {
		if (index != array.length) {
			if(array[index] == 0) {
				return cuentaCerosArrayRecursivamente(array, index+1)+1;
			}
			else {
				return cuentaCerosArrayRecursivamente(array, index+1);
			}
		}
		return 0;
	}

	public int[] getArray() {
		return array;
	}

	public void setArray(int[] array) {
		this.array = array;
	}

	public int getResultado() {
		return resultado;
	}

	public void setResultado(int resultado) {
		this.resultado = resultado;
	}
}