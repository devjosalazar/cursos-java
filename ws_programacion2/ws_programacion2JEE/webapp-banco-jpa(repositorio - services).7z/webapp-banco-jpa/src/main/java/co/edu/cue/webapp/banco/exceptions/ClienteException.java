package co.edu.cue.webapp.banco.exceptions;

public class ClienteException extends  Exception{

    public ClienteException(String mensaje) {
        super(mensaje);
    }
}
